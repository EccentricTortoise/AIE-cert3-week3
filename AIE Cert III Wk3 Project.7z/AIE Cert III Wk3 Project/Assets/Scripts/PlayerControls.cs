﻿using UnityEngine;
using System.Collections;

public class PlayerControls : MonoBehaviour
{
	float playerSpeed = 0f;
	float speedCap = 35f;
	float playerAccel = 0.5f;
	float playerFrict = 0.5f;

	bool moving = false;
	int moveDir = 0; //0 = forward, 1 = left, 2 = backward, 3 = right

	// Use this for initialization
	void Start ()
	{
	
	}
	
	// Update is called once per frame
	void Update ()
	{
		if (moving)
		{
			if (playerSpeed < speedCap)
			{
				playerSpeed += playerAccel;
			}
		}
		else
		{
			if (playerSpeed > 0)
			{
				playerSpeed -= playerFrict;
			}
		}

		if (Input.GetKey (KeyCode.W))
		{
			moveDir = 0;
			moving = true;
		}
		else { moving = false; }

		if (Input.GetKey (KeyCode.A))
		{
			moveDir = 1;
			moving = true;
		}
		else { moving = false; }

		if (Input.GetKey (KeyCode.S))
		{
			moveDir = 2;
			moving = true;
		}
		else { moving = false; }

		if (Input.GetKey (KeyCode.D))
		{
			moveDir = 3;
			moving = true;
		}
		else { moving = false; }

		switch (moveDir)
		{
			case 0:
				transform.Translate (playerSpeed * Time.deltaTime, 0, 0);
				break;

			case 1:
				transform.Translate (0, 0, -playerSpeed * Time.deltaTime);
				break;

			case 2:
				transform.Translate (-playerSpeed * Time.deltaTime, 0, 0);
				break;

			case 3:
				transform.Translate (0, 0, playerSpeed * Time.deltaTime);
				break;
		}
	}
}
